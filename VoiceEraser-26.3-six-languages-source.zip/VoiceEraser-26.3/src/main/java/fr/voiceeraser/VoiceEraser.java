package fr.voiceeraser;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.ChunkPos;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;
import java.io.InputStream;
import java.nio.file.StandardCopyOption;

public final class VoiceEraser implements ModInitializer {
    public static final String MOD_ID = "voice_eraser";
    private static int radiusChunks = 4;
    private static boolean affectBlocks = true;
    private static boolean affectEntities = true;
    private static boolean affectInventories = true;
    private static boolean affectPlayers = true;
    private static final Map<String, Set<String>> LANGUAGE_ALIASES = new HashMap<>();
    private static final String[] LANGUAGE_FILES = {"fr", "en", "es", "de", "it", "pt"};

    @Override
    public void onInitialize() {
        loadConfig();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("voiceeraser")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("test")
                    .then(Commands.argument("spoken_name", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            ServerPlayer speaker = ctx.getSource().getPlayerOrException();
                            String phrase = StringArgumentType.getString(ctx, "spoken_name");
                            int changed = applySpokenName(speaker, phrase);
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                "Voice Eraser prototype: '" + phrase + "' -> " + changed + " target(s)."), false);
                            return changed;
                        })))
                .then(Commands.literal("reload")
                    .executes(ctx -> {
                        loadConfig();
                        ctx.getSource().sendSuccess(() -> Component.literal("Voice Eraser config reloaded."), true);
                        return 1;
                    }))));
    }

    /** Entry point intended to be called by the speech-to-text adapter in the full release. */
    public static int applySpokenName(ServerPlayer speaker, String spokenText) {
        String phrase = normalize(spokenText);
        if (phrase.isBlank()) return 0;
        ServerLevel level = speaker.serverLevel();
        double radius = radiusChunks * 16.0;
        AABB area = speaker.getBoundingBox().inflate(radius);
        int changed = 0;

        if (affectPlayers) {
            for (ServerPlayer target : level.players()) {
                if (target != speaker && target.distanceToSqr(speaker) <= radius * radius
                    && normalize(target.getGameProfile().getName()).equals(phrase)) {
                    target.hurtServer(level, level.damageSources().generic(), Float.MAX_VALUE);
                    changed++;
                }
            }
        }

        if (affectEntities) {
            for (Entity entity : level.getEntities(speaker, area, e -> e.isAlive() && !(e instanceof ServerPlayer))) {
                String id = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).getPath();
                if (matches(phrase, id, entity.getType())) {
                    entity.discard();
                    changed++;
                }
            }
        }

        if (affectInventories) {
            for (ServerPlayer player : level.players()) {
                if (player.distanceToSqr(speaker) > radius * radius) continue;
                for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
                    ItemStack stack = player.getInventory().getItem(slot);
                    if (!stack.isEmpty() && matchesItem(phrase, stack)) {
                        player.getInventory().setItem(slot, ItemStack.EMPTY);
                        changed++;
                    }
                }
            }
        }

        if (affectBlocks) {
            BlockPos origin = speaker.blockPosition();
            int minChunkX = new ChunkPos(origin).x - radiusChunks;
            int maxChunkX = new ChunkPos(origin).x + radiusChunks;
            int minChunkZ = new ChunkPos(origin).z - radiusChunks;
            int maxChunkZ = new ChunkPos(origin).z + radiusChunks;
            int minY = level.getMinY();
            int maxY = level.getMaxY();
            for (int cx = minChunkX; cx <= maxChunkX; cx++) {
                for (int cz = minChunkZ; cz <= maxChunkZ; cz++) {
                    if (!level.hasChunk(cx, cz)) continue;
                    int x0 = cx << 4, z0 = cz << 4;
                    for (int x = x0; x < x0 + 16; x++) {
                        for (int z = z0; z < z0 + 16; z++) {
                            if (Math.abs(x - origin.getX()) > radius || Math.abs(z - origin.getZ()) > radius) continue;
                            for (int y = minY; y < maxY; y++) {
                                BlockPos pos = new BlockPos(x, y, z);
                                BlockState state = level.getBlockState(pos);
                                if (!state.isAir() && matchesBlock(phrase, state)) {
                                    level.destroyBlock(pos, false, speaker);
                                    changed++;
                                }
                            }
                        }
                    }
                }
            }
        }
        return changed;
    }

    private static boolean matches(String phrase, String id, EntityType<?> type) {
        String path = normalize(id.replace('_', ' '));
        return phrase.equals(path) || phrase.equals(normalize(id)) || hasAlias("entity." + id, phrase);
    }

    private static boolean matchesItem(String phrase, ItemStack stack) {
        String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
        return phrase.equals(normalize(id.replace('_', ' '))) || phrase.equals(normalize(id))
            || hasAlias("item." + id, phrase);
    }

    private static boolean matchesBlock(String phrase, BlockState state) {
        ResourceLocation id = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        return phrase.equals(normalize(id.getPath().replace('_', ' '))) || phrase.equals(normalize(id.getPath()))
            || hasAlias("block." + id.getPath(), phrase);
    }

    private static boolean hasAlias(String key, String phrase) {
        return LANGUAGE_ALIASES.getOrDefault(key, Set.of()).contains(phrase);
    }

    private static void loadLanguageAliases() {
        LANGUAGE_ALIASES.clear();
        Path directory = Path.of("config", "voice-eraser", "languages");
        try {
            Files.createDirectories(directory);
            for (String language : LANGUAGE_FILES) {
                Path file = directory.resolve(language + ".properties");
                if (Files.notExists(file)) {
                    String resource = "/assets/voice_eraser/languages/" + language + ".properties";
                    try (InputStream in = VoiceEraser.class.getResourceAsStream(resource)) {
                        if (in != null) Files.copy(in, file, StandardCopyOption.REPLACE_EXISTING);
                    }
                }
                if (Files.exists(file)) {
                    Properties aliases = new Properties();
                    try (Reader reader = Files.newBufferedReader(file)) { aliases.load(reader); }
                    for (String key : aliases.stringPropertyNames()) {
                        Set<String> values = LANGUAGE_ALIASES.computeIfAbsent(key, ignored -> new HashSet<>());
                        for (String value : aliases.getProperty(key, "").split("\\|")) {
                            String normalized = normalize(value);
                            if (!normalized.isBlank()) values.add(normalized);
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("[Voice Eraser] Could not load language aliases: " + e.getMessage());
        }
    }

    private static String normalize(String text) {
        return text.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
    }

    private static void loadConfig() {
        Path path = Path.of("config", "voice-eraser.properties");
        Properties p = new Properties();
        try {
            Files.createDirectories(path.getParent());
            if (Files.exists(path)) {
                try (Reader reader = Files.newBufferedReader(path)) { p.load(reader); }
            } else {
                p.setProperty("radius-chunks", "4");
                p.setProperty("affect-blocks", "true");
                p.setProperty("affect-entities", "true");
                p.setProperty("affect-inventories", "true");
                p.setProperty("affect-players", "true");
                try (Writer writer = Files.newBufferedWriter(path)) {
                    p.store(writer, "Voice Eraser settings. Destructive actions are enabled by default.");
                }
            }
            radiusChunks = Math.max(1, Math.min(16, Integer.parseInt(p.getProperty("radius-chunks", "4"))));
            affectBlocks = Boolean.parseBoolean(p.getProperty("affect-blocks", "true"));
            affectEntities = Boolean.parseBoolean(p.getProperty("affect-entities", "true"));
            affectInventories = Boolean.parseBoolean(p.getProperty("affect-inventories", "true"));
            affectPlayers = Boolean.parseBoolean(p.getProperty("affect-players", "true"));
            loadLanguageAliases();
        } catch (IOException | NumberFormatException e) {
            System.err.println("[Voice Eraser] Could not load config: " + e.getMessage());
        }
    }
}
