# Voice Eraser — Minecraft 26.3 / Fabric

**Status: source prototype; not a finished voice-enabled release.**

This project is based on the supplied Voice Eraser archive. It contains a Fabric mod scaffold and a server-authoritative action processor. It does **not** yet contain the Simple Voice Chat audio bridge or speech-to-text engine, so it cannot react to spoken words yet.

## Target
- Minecraft Java 26.3
- Fabric Loader 0.19.5+
- Fabric API 0.162.0+26.3
- Java 25
- Install on both server and clients; destructive world actions are performed server-side.

## Six editable language configuration files
On first launch, the mod copies these files into `config/voice-eraser/languages/`:
- `fr.properties` — French
- `en.properties` — English
- `es.properties` — Spanish
- `de.properties` — German
- `it.properties` — Italian
- `pt.properties` — Portuguese

Each entry has the form `entity.zombified_piglin=pigman|zombie pigman|...`. Add aliases separated by `|`. Matching normalizes case, accents and punctuation. These are editable synonym dictionaries, not full automatic translation or speech recognition.

## Current test command
As an operator, run:

```text
/voiceeraser test pigman
```

This invokes the action processor manually. It is **not voice activated**. Test only in a disposable world: the processor can destroy blocks, discard entities, remove inventory stacks, and kill matching players.

## Build requirements
Install JDK 25 and Gradle 9.6, then run:

```bash
gradle build
```

The remapped mod JAR should be generated in `build/libs/` when the build succeeds.

## Still required before a Modrinth / CurseForge release
1. Implement and test a supported Simple Voice Chat audio packet integration.
2. Decode the voice stream and connect it to a multilingual speech-to-text engine.
3. Add confidence thresholds, cooldowns, and protection against accidental destructive triggers.
4. Test on a dedicated Minecraft 26.3 Fabric server with multiple clients.

Simple Voice Chat transports audio; it does not itself convert speech to text. The current project does not upload microphone audio to a cloud service.
